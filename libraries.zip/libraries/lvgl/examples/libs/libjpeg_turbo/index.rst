Load a JPG image
-----------------

.. lv_example:: libs/libjpeg_turbo/lv_example_libjpeg_turbo_1
  :language: c

