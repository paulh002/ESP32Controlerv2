Simple Horizontal Gradient
--------------------------

.. lv_example:: get_started/lv_example_grad_1
  :language: c

Linear (Skew) Gradient
----------------------

.. lv_example:: get_started/lv_example_grad_2
  :language: c

Radial Gradient
---------------

.. lv_example:: get_started/lv_example_grad_3
  :language: c

Conical Gradient
----------------

.. lv_example:: get_started/lv_example_grad_4
  :language: c
